--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.4 (Debian 11.4-1.pgdg90+1)
-- Dumped by pg_dump version 11.4 (Debian 11.4-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE stage_db;
--
-- Name: stage_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE stage_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE stage_db OWNER TO postgres;

\connect stage_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: stage_test
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO stage_test;

--
-- Name: anchors; Type: TABLE; Schema: public; Owner: stage_test
--

CREATE TABLE public.anchors (
    id integer NOT NULL,
    name character varying(60) NOT NULL,
    entry_time timestamp without time zone,
    address character varying(120),
    momo_number character varying(60) NOT NULL,
    mobile_number character varying(60),
    id_number character varying(60),
    basic_salary_or_not boolean,
    basic_salary double precision,
    live_time double precision,
    live_session character varying(60),
    percentage double precision,
    ace_anchor_or_not boolean,
    agent character varying(60)
);


ALTER TABLE public.anchors OWNER TO stage_test;

--
-- Name: anchors_id_seq; Type: SEQUENCE; Schema: public; Owner: stage_test
--

CREATE SEQUENCE public.anchors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.anchors_id_seq OWNER TO stage_test;

--
-- Name: anchors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stage_test
--

ALTER SEQUENCE public.anchors_id_seq OWNED BY public.anchors.id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: stage_test
--

CREATE TABLE public.comments (
    id integer NOT NULL,
    date timestamp without time zone,
    anchor_momo character varying(60),
    comment text
);


ALTER TABLE public.comments OWNER TO stage_test;

--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: stage_test
--

CREATE SEQUENCE public.comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comments_id_seq OWNER TO stage_test;

--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stage_test
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: stage_test
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    name character varying(60),
    description character varying(200)
);


ALTER TABLE public.departments OWNER TO stage_test;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: stage_test
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_id_seq OWNER TO stage_test;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stage_test
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: stage_test
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    email character varying(60),
    username character varying(60),
    password_hash character varying(128),
    department_id integer,
    role_id integer,
    is_admin boolean
);


ALTER TABLE public.employees OWNER TO stage_test;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: stage_test
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employees_id_seq OWNER TO stage_test;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stage_test
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: stage_test
--

CREATE TABLE public.logs (
    id integer NOT NULL,
    date timestamp without time zone NOT NULL,
    action character varying(20) NOT NULL,
    target_table character varying(120),
    target_id character varying(20),
    "user" character varying(20) NOT NULL,
    status character varying(5)
);


ALTER TABLE public.logs OWNER TO stage_test;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: stage_test
--

CREATE SEQUENCE public.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logs_id_seq OWNER TO stage_test;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stage_test
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: payrolls; Type: TABLE; Schema: public; Owner: stage_test
--

CREATE TABLE public.payrolls (
    id integer NOT NULL,
    date timestamp without time zone,
    coins double precision,
    guild_division double precision,
    anchor_reward double precision,
    profit double precision,
    penalty double precision,
    salary double precision,
    comment text,
    anchor_momo character varying(60)
);


ALTER TABLE public.payrolls OWNER TO stage_test;

--
-- Name: payrolls_id_seq; Type: SEQUENCE; Schema: public; Owner: stage_test
--

CREATE SEQUENCE public.payrolls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payrolls_id_seq OWNER TO stage_test;

--
-- Name: payrolls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stage_test
--

ALTER SEQUENCE public.payrolls_id_seq OWNED BY public.payrolls.id;


--
-- Name: penalties; Type: TABLE; Schema: public; Owner: stage_test
--

CREATE TABLE public.penalties (
    id integer NOT NULL,
    date timestamp without time zone,
    anchor_momo character varying(60),
    amount double precision
);


ALTER TABLE public.penalties OWNER TO stage_test;

--
-- Name: penalties_id_seq; Type: SEQUENCE; Schema: public; Owner: stage_test
--

CREATE SEQUENCE public.penalties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.penalties_id_seq OWNER TO stage_test;

--
-- Name: penalties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stage_test
--

ALTER SEQUENCE public.penalties_id_seq OWNED BY public.penalties.id;


--
-- Name: raw_data_201907; Type: TABLE; Schema: public; Owner: stage_test
--

CREATE TABLE public.raw_data_201907 (
    index bigint,
    "月份" text,
    "播主昵称" text,
    "播主姓名" text,
    "陌陌号" bigint,
    "总陌币" double precision,
    "公会分成金额" double precision,
    "播主奖励" double precision,
    "实际收入" double precision,
    "罚款" double precision,
    "保底 " double precision,
    "提成" double precision,
    "主播实开" double precision,
    "王牌" double precision,
    "备注" double precision
);


ALTER TABLE public.raw_data_201907 OWNER TO stage_test;

--
-- Name: raw_data_201908; Type: TABLE; Schema: public; Owner: stage_test
--

CREATE TABLE public.raw_data_201908 (
    index bigint,
    "月份" text,
    "播主昵称" text,
    "播主姓名" text,
    "陌陌号" bigint,
    "所属经纪人" text,
    "经纪人陌陌号" double precision,
    "连麦陌币" double precision,
    "非连麦陌币" bigint,
    "总陌币" double precision,
    "结算方式" text,
    "播主分成金额" double precision,
    "公会分成金额" double precision,
    "播主奖励" double precision,
    "结算金额" double precision,
    "实际收入" double precision
);


ALTER TABLE public.raw_data_201908 OWNER TO stage_test;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: stage_test
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(60),
    description character varying(200)
);


ALTER TABLE public.roles OWNER TO stage_test;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: stage_test
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO stage_test;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stage_test
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: anchors id; Type: DEFAULT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.anchors ALTER COLUMN id SET DEFAULT nextval('public.anchors_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: payrolls id; Type: DEFAULT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.payrolls ALTER COLUMN id SET DEFAULT nextval('public.payrolls_id_seq'::regclass);


--
-- Name: penalties id; Type: DEFAULT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.penalties ALTER COLUMN id SET DEFAULT nextval('public.penalties_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: stage_test
--

COPY public.alembic_version (version_num) FROM stdin;
\.
COPY public.alembic_version (version_num) FROM '$$PATH$$/2960.dat';

--
-- Data for Name: anchors; Type: TABLE DATA; Schema: public; Owner: stage_test
--

COPY public.anchors (id, name, entry_time, address, momo_number, mobile_number, id_number, basic_salary_or_not, basic_salary, live_time, live_session, percentage, ace_anchor_or_not, agent) FROM stdin;
\.
COPY public.anchors (id, name, entry_time, address, momo_number, mobile_number, id_number, basic_salary_or_not, basic_salary, live_time, live_session, percentage, ace_anchor_or_not, agent) FROM '$$PATH$$/2961.dat';

--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: stage_test
--

COPY public.comments (id, date, anchor_momo, comment) FROM stdin;
\.
COPY public.comments (id, date, anchor_momo, comment) FROM '$$PATH$$/2963.dat';

--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: stage_test
--

COPY public.departments (id, name, description) FROM stdin;
\.
COPY public.departments (id, name, description) FROM '$$PATH$$/2965.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: stage_test
--

COPY public.employees (id, email, username, password_hash, department_id, role_id, is_admin) FROM stdin;
\.
COPY public.employees (id, email, username, password_hash, department_id, role_id, is_admin) FROM '$$PATH$$/2967.dat';

--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: stage_test
--

COPY public.logs (id, date, action, target_table, target_id, "user", status) FROM stdin;
\.
COPY public.logs (id, date, action, target_table, target_id, "user", status) FROM '$$PATH$$/2969.dat';

--
-- Data for Name: payrolls; Type: TABLE DATA; Schema: public; Owner: stage_test
--

COPY public.payrolls (id, date, coins, guild_division, anchor_reward, profit, penalty, salary, comment, anchor_momo) FROM stdin;
\.
COPY public.payrolls (id, date, coins, guild_division, anchor_reward, profit, penalty, salary, comment, anchor_momo) FROM '$$PATH$$/2971.dat';

--
-- Data for Name: penalties; Type: TABLE DATA; Schema: public; Owner: stage_test
--

COPY public.penalties (id, date, anchor_momo, amount) FROM stdin;
\.
COPY public.penalties (id, date, anchor_momo, amount) FROM '$$PATH$$/2973.dat';

--
-- Data for Name: raw_data_201907; Type: TABLE DATA; Schema: public; Owner: stage_test
--

COPY public.raw_data_201907 (index, "月份", "播主昵称", "播主姓名", "陌陌号", "总陌币", "公会分成金额", "播主奖励", "实际收入", "罚款", "保底 ", "提成", "主播实开", "王牌", "备注") FROM stdin;
\.
COPY public.raw_data_201907 (index, "月份", "播主昵称", "播主姓名", "陌陌号", "总陌币", "公会分成金额", "播主奖励", "实际收入", "罚款", "保底 ", "提成", "主播实开", "王牌", "备注") FROM '$$PATH$$/2975.dat';

--
-- Data for Name: raw_data_201908; Type: TABLE DATA; Schema: public; Owner: stage_test
--

COPY public.raw_data_201908 (index, "月份", "播主昵称", "播主姓名", "陌陌号", "所属经纪人", "经纪人陌陌号", "连麦陌币", "非连麦陌币", "总陌币", "结算方式", "播主分成金额", "公会分成金额", "播主奖励", "结算金额", "实际收入") FROM stdin;
\.
COPY public.raw_data_201908 (index, "月份", "播主昵称", "播主姓名", "陌陌号", "所属经纪人", "经纪人陌陌号", "连麦陌币", "非连麦陌币", "总陌币", "结算方式", "播主分成金额", "公会分成金额", "播主奖励", "结算金额", "实际收入") FROM '$$PATH$$/2976.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: stage_test
--

COPY public.roles (id, name, description) FROM stdin;
\.
COPY public.roles (id, name, description) FROM '$$PATH$$/2977.dat';

--
-- Name: anchors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stage_test
--

SELECT pg_catalog.setval('public.anchors_id_seq', 698, true);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stage_test
--

SELECT pg_catalog.setval('public.comments_id_seq', 1, false);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stage_test
--

SELECT pg_catalog.setval('public.departments_id_seq', 1, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stage_test
--

SELECT pg_catalog.setval('public.employees_id_seq', 5, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stage_test
--

SELECT pg_catalog.setval('public.logs_id_seq', 537, true);


--
-- Name: payrolls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stage_test
--

SELECT pg_catalog.setval('public.payrolls_id_seq', 1, false);


--
-- Name: penalties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stage_test
--

SELECT pg_catalog.setval('public.penalties_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stage_test
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: anchors anchors_pkey; Type: CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.anchors
    ADD CONSTRAINT anchors_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: departments departments_name_key; Type: CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_name_key UNIQUE (name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: payrolls payrolls_pkey; Type: CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT payrolls_pkey PRIMARY KEY (id);


--
-- Name: penalties penalties_pkey; Type: CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.penalties
    ADD CONSTRAINT penalties_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: ix_anchors_momo_number; Type: INDEX; Schema: public; Owner: stage_test
--

CREATE UNIQUE INDEX ix_anchors_momo_number ON public.anchors USING btree (momo_number);


--
-- Name: ix_anchors_name; Type: INDEX; Schema: public; Owner: stage_test
--

CREATE INDEX ix_anchors_name ON public.anchors USING btree (name);


--
-- Name: ix_employees_email; Type: INDEX; Schema: public; Owner: stage_test
--

CREATE UNIQUE INDEX ix_employees_email ON public.employees USING btree (email);


--
-- Name: ix_employees_username; Type: INDEX; Schema: public; Owner: stage_test
--

CREATE UNIQUE INDEX ix_employees_username ON public.employees USING btree (username);


--
-- Name: ix_raw_data_201907_index; Type: INDEX; Schema: public; Owner: stage_test
--

CREATE INDEX ix_raw_data_201907_index ON public.raw_data_201907 USING btree (index);


--
-- Name: ix_raw_data_201908_index; Type: INDEX; Schema: public; Owner: stage_test
--

CREATE INDEX ix_raw_data_201908_index ON public.raw_data_201908 USING btree (index);


--
-- Name: comments comments_anchor_momo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_anchor_momo_fkey FOREIGN KEY (anchor_momo) REFERENCES public.anchors(momo_number);


--
-- Name: employees employees_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: employees employees_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: payrolls payrolls_anchor_momo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT payrolls_anchor_momo_fkey FOREIGN KEY (anchor_momo) REFERENCES public.anchors(momo_number);


--
-- Name: penalties penalties_anchor_momo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: stage_test
--

ALTER TABLE ONLY public.penalties
    ADD CONSTRAINT penalties_anchor_momo_fkey FOREIGN KEY (anchor_momo) REFERENCES public.anchors(momo_number);


--
-- Name: DATABASE stage_db; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE stage_db TO stage_test;


--
-- PostgreSQL database dump complete
--

